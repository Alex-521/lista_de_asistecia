import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-del',
  templateUrl: './del.page.html',
  styleUrls: ['./del.page.scss'],
})
export class DelPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
